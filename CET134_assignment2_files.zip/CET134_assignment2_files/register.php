<?php
//use this script to register users
include 'dbconnect.php';

$username= $_POST['username'];
$email=$_POST['email'];
$password=$_POST['password'];

try {
    $con= new PDO ("mysql:host=$servername;dbname=$database", $username, $password");
    $con -> setAttribute(PDO:: ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    
  $sql = INSERT INTO `register` (`id`, `name`, `email`, `password`) VALUES (NULL, '$username', '$email', '$password')
   
  $con-> exec(sql);
  echo "Registration successful",
 }

catch(PODException $e)
{
    echo $sql . "<br>". $e->getmessage();
}

}
else {
    echo "registration failed";
}


?>