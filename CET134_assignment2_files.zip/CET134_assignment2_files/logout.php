<?php
//use this script to logout

?>