<?php
//use this script to delete faults

?>