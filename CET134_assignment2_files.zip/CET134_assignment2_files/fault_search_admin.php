<?php
//use this script to search for faults as an admin user

?>