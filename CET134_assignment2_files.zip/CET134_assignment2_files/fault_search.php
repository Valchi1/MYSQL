<?php
//use this script to search for a fault

?>