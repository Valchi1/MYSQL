<


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
        }
    </style>
</head>
<body>
    <form action ="login_form.html" method="post">
        <label for="user_email">Email</label>
        <input type="text" id ="user_email" name="user_email">
        <br>
        <label for="user_password">Password</label>
        <input type="text" id ="user_password" name="user_password">
        <br>

       <input type="submit">
    </form>
</body>
</html>
