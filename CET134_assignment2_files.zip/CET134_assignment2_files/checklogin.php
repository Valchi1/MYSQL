<?php
//use this file to check if the user is logged in, by checking the value of a session variable
//use the include command to include in other scripts

?>