<?php
//use this script to view faults reported by the logged in user

?>