<?php
//use this script to view all of the faults as an admin user

?>