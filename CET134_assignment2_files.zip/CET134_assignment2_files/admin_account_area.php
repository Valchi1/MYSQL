<?php
//use this script as the homepage area for admins

?>