<?php
//use this script to view all of the faults

?>